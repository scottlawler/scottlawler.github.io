import boto3, uuid, json
from boto3.dynamodb.conditions import Key
from datetime import datetime, timedelta, timezone

SKIP = {'WatcherGuid','WatcherID','Active','PRIORITY','RecordId','watcherResultsGuid','UserId','TransactionID','TransactionTime','TransactionUTCTime','MatchScore','MatchType','AlertType','Acknowledged','WatcherID'}

def alert_type(fields):
    fs = set(fields)
    if any(f in fs for f in ['SenderFirstName','SenderLastName','ReceiverFirstName','ReceiverLastName','SenderAddressLine1','ReceiverAddressLine1','SenderAddressLine2','ReceiverAddrssLine2']):
        return 'PEP_MATCH'
    if any(f in fs for f in ['SenderBankAccountNumber','ReceiverBankAccountNumber']):
        return 'SHELL_COMPANY'
    if any(f in fs for f in ['SenderBankRoutingNumber','ReceiverBankRoutingNumber']):
        return 'RAPID_MOVEMENT'
    if 'Amount' in fs: return 'DOLLAR_MATCH'
    if any(f in fs for f in ['ReceiverCountry','ReceiverCity','SenderCity','ReceiverState','SenderState','ReceiverPostcode','SenderPostcode']):
        return 'HIGH_RISK_COUNTRY'
    return 'WATCHER_MATCH'

def lambda_handler(event, context):
    ddb = boto3.resource('dynamodb', region_name='us-east-1')
    crit_tbl = ddb.Table('matchCriteria-prod')
    src_tbl  = ddb.Table('sourceData-prod')
    res_tbl  = ddb.Table('matchResults-prod')
    usr_tbl  = ddb.Table('userProfile-prod')

    # Registered users
    users = {i['userId'] for i in usr_tbl.scan().get('Items',[])}

    # All criteria grouped by WatcherID — query via GSI per user (no expensive scan)
    user_crit = {}
    for user_id in users:
        q = {"IndexName": "WatcherID-index", "KeyConditionExpression": Key("WatcherID").eq(user_id)}
        while True:
            resp = crit_tbl.query(**q)
            for c in resp.get('Items', []):
                user_crit.setdefault(user_id, []).append(c)
            if 'LastEvaluatedKey' not in resp: break
            q["ExclusiveStartKey"] = resp["LastEvaluatedKey"]

    # Recent transactions (last 8 minutes)
    cutoff = (datetime.now(timezone.utc)-timedelta(minutes=8)).strftime('%Y-%m-%d %H:%M:%S')
    txns = []
    resp = src_tbl.scan(FilterExpression='TransactionTime >= :t', ExpressionAttributeValues={':t':cutoff})
    while True:
        txns.extend(resp.get('Items',[]))
        if 'LastEvaluatedKey' not in resp: break
        resp = src_tbl.scan(FilterExpression='TransactionTime >= :t', ExpressionAttributeValues={':t':cutoff}, ExclusiveStartKey=resp['LastEvaluatedKey'])

    matched = 0
    for user_id, criteria_list in user_crit.items():
        if user_id not in users: continue
        for txn in txns:
            txn_id = txn.get('TransactionID','')
            for crit in criteria_list:
                if crit.get('Active','Y').strip().upper() not in ('Y','YES','TRUE','1',''):
                    continue
                # Check all non-system fields in criterion against transaction
                matched_fields = []
                ok = True
                has_crit = False
                for field, val in crit.items():
                    if field in SKIP or not val or not str(val).strip(): continue
                    has_crit = True
                    txn_val = str(txn.get(field,'')).strip()
                    if not txn_val:
                        ok = False; break
                    if str(val).strip().lower() != txn_val.lower():
                        ok = False; break
                    matched_fields.append(field)
                if not has_crit or not ok or not matched_fields: continue

                # Deterministic UUID prevents duplicates for same match
                dedup_key = f"{txn_id}:{user_id}:{crit.get('WatcherGuid','')}"
                wrg = str(uuid.uuid5(uuid.NAMESPACE_DNS, dedup_key))

                result = dict(txn)
                result['watcherResultsGuid'] = wrg
                result['UserId'] = user_id
                result['WatcherGuid'] = crit.get('WatcherGuid','')
                result['AlertType'] = alert_type(matched_fields)
                result['PRIORITY'] = crit.get('PRIORITY','')
                result['MatchScore'] = str(round(len(matched_fields)/max(1,has_crit)*100))
                result['MatchType'] = 'EXACT'
                result['MatchedFields'] = ','.join(matched_fields)
                result['Acknowledged'] = 'N'
                # Remove keys that might conflict
                result.pop('SenderBankAccountNumber', None)
                result.pop('ReceiverBankAccountNumber', None)

                res_tbl.put_item(Item=result)
                matched += 1
                break  # one match per transaction per user

    print(f"Matched {matched} of {len(txns)} recent txns for {len(user_crit)} users")
    return {'matched': matched, 'txns_checked': len(txns)}
