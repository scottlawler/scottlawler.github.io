import json
import boto3
import logging
from datetime import datetime, timezone, timedelta
from decimal import Decimal
from boto3.dynamodb.conditions import Attr, Key

logger = logging.getLogger()
logger.setLevel(logging.INFO)

HEADERS = {
    "Access-Control-Allow-Headers": "Content-Type",
    "Access-Control-Allow-Origin": "*",
    "Access-Control-Allow-Methods": "OPTIONS,POST,GET"
}

class DecimalEncoder(json.JSONEncoder):
    def default(self, o):
        if isinstance(o, Decimal):
            return float(o) if o % 1 else int(o)
        return super().default(o)

def extract_params(event):
    qsp = event.get("queryStringParameters") or {}
    user_id = qsp.get("userId") or event.get("userId") or "jimmy"
    data_age = qsp.get("dataAgeHours") or event.get("dataAgeHours") or "24"
    try:
        data_age = int(float(str(data_age)))
    except Exception:
        data_age = 24
    return user_id, data_age

def query_by_user(table, user_id, cutoff_str, index="UserId-TransactionTime-index"):
    items = []
    kwargs = {
        "IndexName": index,
        "KeyConditionExpression": Key("UserId").eq(user_id) & Key("TransactionTime").gte(cutoff_str)
    }
    while True:
        resp = table.query(**kwargs)
        items.extend(resp.get("Items", []))
        nk = resp.get("LastEvaluatedKey")
        if not nk:
            break
        kwargs["ExclusiveStartKey"] = nk
    return items

def lambda_handler(event, context):
    logger.info("Event: " + str(event))
    user_id, data_age_hours = extract_params(event)
    logger.info("userId=" + user_id + " dataAgeHours=" + str(data_age_hours))
    now = datetime.now(timezone.utc)
    cutoff = now - timedelta(hours=data_age_hours)
    cutoff_str = cutoff.strftime("%Y-%m-%d %H:%M:%S")
    logger.info("cutoff=" + cutoff_str)
    db = boto3.resource("dynamodb", region_name="us-east-1")
    items = []
    # Try matchResults-prod first (has AlertType, MatchScore, PRIORITY)
    try:
        logger.info("Querying matchResults-prod via GSI...")
        items = query_by_user(db.Table("matchResults-prod"), user_id, cutoff_str)
        logger.info("matchResults-prod: " + str(len(items)) + " items")
    except Exception as e:
        logger.warning("matchResults-prod failed: " + str(e))
        items = []
    # Fallback to sourceData-prod
    if not items:
        try:
            logger.info("Querying sourceData-prod via GSI...")
            items = query_by_user(db.Table("sourceData-prod"), user_id, cutoff_str)
            logger.info("sourceData-prod: " + str(len(items)) + " items")
        except Exception as e:
            logger.error("sourceData-prod failed: " + str(e))
            items = []
    if not items:
        return {"statuscode": 400, "message": "No matches found", "headers": HEADERS, "body": []}
    clean = json.loads(json.dumps(items, cls=DecimalEncoder))
    logger.info("Returning " + str(len(clean)) + " records")
    return {"statuscode": 200, "message": "Findata", "headers": HEADERS, "body": clean}
