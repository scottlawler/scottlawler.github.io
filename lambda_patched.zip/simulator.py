import boto3, uuid, random, json, time
from datetime import datetime, timezone, timedelta
from boto3.dynamodb.conditions import Attr, Key

REGION         = "us-east-1"
SOURCE_TABLE   = "sourceData-prod"
MATCH_TABLE    = "matchResults-prod"
CRITERIA_TABLE = "matchCriteria-prod"
RULE_NAME      = "findata-data-simulator-schedule"
MIN_INTERVAL   = 1
MAX_INTERVAL   = 7
ROLLOFF_HOURS  = 2
MATCH_ACCT_PROB = 0.35   # probability a transaction uses a watched account number

FIRST = ["James","John","Robert","Maria","Jennifer","Michael","Lisa","David","Sarah","Carlos",
         "Ana","Wei","Priya","Ahmed","Sophie","Emma","Liam","Olivia","Noah","Ava",
         "Gustavo","Florence","Derrick","Cora","Noah"]
LAST  = ["Smith","Johnson","Williams","Brown","Davis","Miller","Wilson","Moore","Taylor",
         "Anderson","Thomas","Jackson","White","Harris","Martin","Garcia","Martinez",
         "Robinson","Clark","Lewis","Mraz","Towne","Murphy"]
CTRY  = ["US","MX","BR","CN","NG","PK","IN","DE","FR","UK","CA","AU","JP","KR","ZA","VE","CO","PE","EG","RU"]
CHAN  = ["WIRE","ACH","SWIFT","SEPA","DOMESTIC","CRYPTO","REMITTANCE"]
ALRT  = ["HIGH_VALUE_TRANSACTION","SANCTIONS_LIST_MATCH","PEP_MATCH","HIGH_RISK_COUNTRY",
         "STRUCTURING","RAPID_MOVEMENT","SHELL_COMPANY","ROUND_DOLLAR_AMOUNTS"]
BANK  = ["Chase Bank","Bank of America","Wells Fargo","Citibank","HSBC","Deutsche Bank",
         "BNP Paribas","Barclays","Standard Chartered","ING"]
RCITY = ["Mexico City","London","Berlin","Sao Paulo","Lagos","Cairo","Mumbai","Seoul","Sydney","Shanghai"]
SCITY = ["New York","Los Angeles","Chicago","Houston","Phoenix","Dallas","Miami","Seattle","Atlanta","Denver"]

def rn(lst): return random.choice(lst)
def routing(): return str(random.randint(100000000, 999999999))
def account(): return str(random.randint(100000000, 999999999))
def tax_id():  return str(random.randint(100000000, 999999999))

def matches_criterion(record, criterion):
    check_fields = [
        "SenderFirstName","SenderLastName","SenderTaxID","SenderAccountID",
        "SenderCity","SenderState","SenderCounty","SenderBankName",
        "SenderBankAccountNumber","SenderBankRoutingNumber",
        "ReceiverFirstName","ReceiverLastName","ReceiverTaxID","ReceiverAccountID",
        "ReceiverCity","ReceiverState","ReceiverCountry","ReceiverBankName",
        "ReceiverBankAccountNumber","ReceiverBankRoutingNumber",
        "Amount","CurrencyCode","Channel","FundsFlow",
    ]
    for field in check_fields:
        c_val = criterion.get(field, "")
        if not c_val:
            continue
        if str(c_val).strip() != str(record.get(field, "")).strip():
            return False
    return True


CHECK_FIELDS = [
    "SenderFirstName","SenderLastName","SenderBankAccountNumber","SenderBankRoutingNumber",
    "ReceiverFirstName","ReceiverLastName","ReceiverBankAccountNumber","ReceiverBankRoutingNumber",
    "Amount","ReceiverCountry","SenderCity","SenderState","ReceiverCity","ReceiverState",
]

def get_matched_fields(record, criteria_list):
    matched = set()
    for crit in criteria_list:
        if matches_criterion(record, crit):
            for field in CHECK_FIELDS:
                c_val = str(crit.get(field, "")).strip()
                r_val = str(record.get(field, "")).strip()
                if c_val and c_val == r_val:
                    matched.add(field)
    return ",".join(sorted(matched))

def lambda_handler(event, context):
    ddb            = boto3.resource("dynamodb", region_name=REGION)
    source_table   = ddb.Table(SOURCE_TABLE)
    match_table    = ddb.Table(MATCH_TABLE)
    criteria_table = ddb.Table(CRITERIA_TABLE)
    events_client  = boto3.client("events", region_name=REGION)

    now_utc        = datetime.now(timezone.utc)
    now_space_iso  = now_utc.strftime("%Y-%m-%d %H:%M:%S")
    now_slash_fmt  = now_utc.strftime("%m/%d/%y %H:%M")
    now_iso_z      = now_utc.strftime("%Y-%m-%dT%H:%M:%S.000Z")

    # Load criteria via GSI (no expensive scan)
    all_criteria = []
    q = {"IndexName": "WatcherID-index", "KeyConditionExpression": Key("WatcherID").eq("jimmy")}
    while True:
        resp = criteria_table.query(**q)
        all_criteria.extend(resp["Items"])
        if "LastEvaluatedKey" not in resp:
            break
        q["ExclusiveStartKey"] = resp["LastEvaluatedKey"]
    print(f"Loaded {len(all_criteria)} criteria via GSI")

    # Extract watched bank account pairs to reuse in generated transactions
    watched_sender_bank_pairs = [
        (c["SenderBankAccountNumber"], c.get("SenderBankRoutingNumber", routing()))
        for c in all_criteria
        if c.get("SenderBankAccountNumber")
    ]
    watched_receiver_bank_pairs = [
        (c["ReceiverBankAccountNumber"], c.get("ReceiverBankRoutingNumber", routing()))
        for c in all_criteria
        if c.get("ReceiverBankAccountNumber")
    ]
    print(f"Watched sender accts: {len(watched_sender_bank_pairs)}, receiver accts: {len(watched_receiver_bank_pairs)}")

    # Rolloff handled by DynamoDB TTL

    # Generate new records and check against criteria
    num_new   = random.randint(5, 12)
    generated = 0
    matched   = 0

    with source_table.batch_writer() as source_bw:
        for _ in range(num_new):
            txn_id  = str(uuid.uuid4())
            sf, sl  = rn(FIRST), rn(LAST)
            rf, rl  = rn(FIRST), rn(LAST)
            sc, rc  = rn(CTRY),  rn(CTRY)
            sb, rb  = rn(BANK),  rn(BANK)

            # Reuse watched bank account numbers with MATCH_ACCT_PROB probability
            if watched_sender_bank_pairs and random.random() < MATCH_ACCT_PROB:
                s_bank_acct, s_bank_rout = rn(watched_sender_bank_pairs)
            else:
                s_bank_acct, s_bank_rout = account(), routing()

            if watched_receiver_bank_pairs and random.random() < MATCH_ACCT_PROB:
                r_bank_acct, r_bank_rout = rn(watched_receiver_bank_pairs)
            else:
                r_bank_acct, r_bank_rout = account(), routing()

            amt     = str(random.randint(5000, 5000000))
            channel = rn(CHAN)
            flow    = random.choice(["DEBIT", "CREDIT"])
            ttl_epoch = int(time.time()) + (ROLLOFF_HOURS * 3600)
            rec = {
                "TransactionID":           txn_id,
                "Amount":                  amt,
                "CurrencyCode":            "USD",
                "Channel":                 channel,
                "FundsFlow":               flow,
                "TransactionUTCTime":      now_slash_fmt,
                "TransactionTime":         now_space_iso,
                "UserId":                  "jimmy",
                "WatcherGuid":             "12421-21412412-124124-124124",
                "AlertType":               rn(ALRT),
                "MatchScore":              str(random.randint(70, 99)),
                "SenderExternalID":        "EXT-" + str(random.randint(10000,99999)),
                "SenderTaxID":             tax_id(),
                "SenderAccountID":         account(),
                "SenderFirstName":         sf,
                "SenderLastName":          sl,
                "SenderAddressLine1":      str(random.randint(100,9999)) + " Main St",
                "SenderAddressLine2":      "",
                "SenderCity":              rn(SCITY),
                "SenderPostcode":          str(random.randint(10000,99999)),
                "SenderCounty":            sc,
                "SenderState":             rn(["NY","CA","TX","FL","IL","PA","OH","GA","NC","MI"]),
                "SenderClientFinClusiveID":"FC-" + str(random.randint(10000,99999)),
                "SenderBankName":          sb,
                "SenderBankAccountNumber": s_bank_acct,
                "SenderBankRoutingNumber": s_bank_rout,
                "ttl": ttl_epoch,
                "ReceiverExternalID":      "EXT-" + str(random.randint(10000,99999)),
                "ReceiverTaxID":           tax_id(),
                "ReceiverAccountID":       account(),
                "ReceiverFirstName":       rf,
                "ReceiverLastName":        rl,
                "ReceiverAddressLine1":    str(random.randint(100,9999)) + " Oak Ave",
                "ReceiverAddrssLine2":     "",
                "ReceiverCity":            rn(RCITY),
                "ReceiverPostcode":        str(random.randint(10000,99999)),
                "ReceiverCountry":         rc,
                "ReceiverBankName":        rb,
                "ReceiverBankAccountNumber": r_bank_acct,
                "ReceiverBankRoutingNumber": r_bank_rout,
                "ReceiverState":           "",
                "ReceiverClientFinClusiveID":"FC-" + str(random.randint(10000,99999)),
            }
            source_bw.put_item(Item=rec)
            generated += 1

            # Live matching against all criteria
            for criterion in all_criteria:
                if matches_criterion(rec, criterion):
                    mr = dict(rec)
                    mr["watcherResultsGuid"] = str(uuid.uuid4())
                    mr["Acknowledged"]       = "N"
                    mr["MatchType"]          = "EXACT"
                    mr["PRIORITY"]           = criterion.get("PRIORITY", "Red")
                    mr["WatcherGuid"]        = criterion.get("WatcherGuid", "12421-21412412-124124-124124")
                    mr["MatchedFields"] = get_matched_fields(rec, all_criteria)
                    match_table.put_item(Item=mr)
                    matched += 1
                    print("MATCH: " + sf + " " + sl + " -> " + rf + " " + rl + " | acct=" + s_bank_acct)
                    break

    print(f"Generated {generated} records, {matched} matched")

    # Self-reschedule at random 1-7 min
    nxt = random.randint(MIN_INTERVAL, MAX_INTERVAL)
    rate = "rate(" + str(nxt) + " minute" + ("s" if nxt > 1 else "") + ")"
    try:
        events_client.put_rule(Name=RULE_NAME, ScheduleExpression=rate,
                               State="ENABLED",
                               Description="Findata simulator - random 1-7 min")
        print("Next run in " + str(nxt) + " min")
    except Exception as e:
        print("Reschedule warning: " + str(e))

    return {
        "statusCode": 200,
        "body": json.dumps({
            "generated": generated,
            "matched": matched,
            "deletedSource": deleted_src,
            "deletedMatch": deleted_mtch,
            "criteriaLoaded": len(all_criteria),
            "watchedSenderAccts": len(watched_sender_bank_pairs),
            "watchedReceiverAccts": len(watched_receiver_bank_pairs),
            "nextIntervalMinutes": nxt,
            "timestamp": now_iso_z
        })
    }
